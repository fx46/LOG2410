#include "TP4_Tests.h"

int main(int argc, char** argv)
{
	TP4_Tests lesTests;

	lesTests.testComposite();
	lesTests.testDecorator();
}